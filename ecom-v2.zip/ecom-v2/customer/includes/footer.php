<footer>
  <div class="footer">
    <i class="fa fa-facebook"></i> <i class="fa fa-instagram"></i> <i class="fa fa-envelope"></i> <i class="fa fa-phone"></i>
    <p>© 2021 Shop mall || All rights reserved || Designed By: DGNR</p>
  </div>
</footer>